package com.example.katalogbuku;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

public class ContohBuku extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contoh_buku);
        onBackPressed();
    }
    public void onBackPressed() {
        Intent kembali = new Intent(ContohBuku.this, MainActivity.class );
        ContohBuku.super.fileList();
        startActivity(kembali);
    }
}